import UIKit

/*:
 **SECTION C, Partial Sum**
 * Shuntaro Abe
 * *CPSC 357 Project 1*
 */


/*:
 Pseudo-code
 * To start off my functions will take in 2 parameters, array and index pairs
 * We create an array called results that will hold the results for each index pair sum
 * We have a for loop that loops through each index pair, and initialize a sum variable each loop
 * Inside the first for loop, we will have another for loop ranging from a to b that += each integer from index a to b
 * At the end of the first for loop, we will append the sum to the results array
 * Return the array
 */



/*:
 This function calculates the partial sums given the array of nummbers, as well as an array of indexPairs. We first initialize an integer array that will hold the results. We loop through the indexPairs and in each loop, we create a sum variable that starts at 0. We then create a nested for loop that loops ranging from a to b. We then add the content of each number in the respective index to sum. After each index pair, we append the result to the results array. We then return the results array.
 * param numbers: an integer array that represents the numbers we will add up
 * param indexPairs: an array that holds (Int,Int) indexPairs
 * return: an array consisting of the results
 */
func partial_sums(numbers: [Int], indexPairs: [(Int,Int)]) -> [Int]{
    var results: [Int] = []
    
    for (a,b) in indexPairs{
        var sum = 0
        for index in a...b{
            sum += numbers[index]
        }
        results.append(sum)
    }
    
    return results
}

//This is used to test my code
var numbers = [3, 6, 4, 15, 30]
var indexPairs = [(1, 3), (0, 4)]
var result = partial_sums(numbers: numbers, indexPairs: indexPairs)
print(result)
