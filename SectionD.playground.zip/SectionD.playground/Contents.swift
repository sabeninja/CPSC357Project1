import UIKit

/*:
 **SECTION D, Rock Paper Scissors**
 * Shuntaro Abe
 * *CPSC 357 Project 1*
 */

/*:
 Pseudo-code
 * Although a function will work, I will create a class to utilize OOP
 * The class will be called Game, and have userMove and cpuMove variables that are strings
 * userMove will be set using the initializer, but the computerMove will be an empty string
 * I will also have a string that has the results of the game
 * I will probably have a function that sets the cpuMove variable using a random number from 0-2. It will then select the move from an array of the three choices (strings)
 * I will also have a function that will see who won, then
 * I will have an if, else if, and else statement
 * if will check if its tie, else if will use or and and to see if we won, and if it's not those, we lost
 * Then we should be able to call said function and print the results to see who won
 * I will also have a function that uses our functions to play the entire game in 1 function, combining the set cpu move and get winner function, then print the result
 */


/*:
 Class: Game. This class has userMove, cpuMove, and results member variables that are all strings. The goal of this class is to get user move, generate cpu move, then play the game all in one object. We also have a constant array that has the list of moves that the computer can pick from. We have an initializer that sets the userMove when the object is initialized, while the cpuMove and results are set in different functions. Each function will be explained separarely below.
 */


/*:
 Member variables
 * userMove: string representing the user move
 * cpuMove: string representing the CPU move
 * result: the result of the game that we will print
 */

/*:
 Initializer: Initialize the userMove variable, while we set the others to an empty string
 */

/*:
 setCPU: This function sets the move for the CPU. We use Swift's random function to get a random number for 0-2. We then set the CPU move by getting the index we generated and the move from the array
 */

/*:
 getWinner: This function determines the winner and sets the result string to the result of the game. If player move and CPU move is the same, the result is a tie. In the else if statement, we have all winning cases for the player, and if any of them matches (using or), we set the results to player win. In any other case, the CPU will win.
 */

/*:
 play: This function combines the other functions in the class and plays the game. We set the CPU move, and determine the winner. We then print the result to the terminal.
 */
class Game{
    

    var userMove: String
    var cpuMove: String
    var result: String
    
    //constant as move selection will never change
    let allMoves = ["rock","paper","scissors"]
    

    init(userMove: String){
        self.userMove = userMove
        self.cpuMove = ""
        self.result = ""
    }
    
    func setCPU(){
        var random = Int.random(in: 0...2)
        self.cpuMove = allMoves[random]
    }
    
    func getWinner(){
        if(userMove == cpuMove){
            self.result = "It's a tie!"
        }
        else if((userMove == "rock" && cpuMove == "scissors") || (userMove == "paper" && cpuMove == "rock") || (userMove == "scissors" && cpuMove == "paper")){
            self.result = "You win!"
        }
        else{
            self.result = "Computer wins!"
        }
    }
    
    func play(){
        setCPU()
        getWinner()
        print(self.result)
    }
}

//Tesing code
var test = Game(userMove: "rock")
test.play()



