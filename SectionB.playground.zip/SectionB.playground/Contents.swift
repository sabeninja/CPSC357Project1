import UIKit

/*:
 SECTION B, Parenthesis Pairs

 * Shuntaro Abe
 * *CPSC 357 Project 1*
 */


/*:
 Pseudo-code
 * I already have an idea of how to do this from an assignment from another class
 * Since we only have one type of parenthesis, it should be simple
 * We create a variable called count
 * We iterate through the string character by character
 * Whenever we encounter an open parenthesis, we add 1 to count
 * Whenever we encounter a closed parenthesis, we subtract 1 from count
 * If count every reaches below 0, that means we encountered more closed than open already so we know that it is not balanced. We can set the boolean to false
 * Once the loop ends, if count is 0, we know we had balanced parentheses, so we can set boolean to true
 * If it's not 0, we know it's imbalanced so we can set it to false
 */


/*:
 The function checkBalances has all of the logic to test if parentheses are balanced. It takes in inputString of type string and return a boolean. We set a count variable to 0, then loop through the inputString. We check each char, if its open parenthesis, we add 1 to the count. if its closed parenthesis, we subtract 1 from the count. During the loop, if count is ever below 0, we simply return false since its not balanced. We then return count == 0 to return a boolean. If it == 0, it will return true as in balanced. Else, it will return false.
 
 * param inputString: the string we will be checking to see if balanced
 * return: a boolean indicating if string is balanced
 */
func checkBalance(inputString: String) -> Bool{
    var count = 0
    
    for char in inputString{
        if char == "("{
            count += 1
        }
        else if char == ")"{
            count -= 1
        }
        if count < 0{
            return false
        }
    }
    return count == 0
}


//Code used to test my function
var test1 = "()"
var test2 = "(()))"

print(checkBalance(inputString: test1))
print(checkBalance(inputString: test2))
